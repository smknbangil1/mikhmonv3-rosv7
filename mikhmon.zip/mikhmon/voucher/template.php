																																																						<?php
if(substr($validity,-1) == "d"){
$validity = "Masa aktif:".substr($validity,0,-1)."Hari";
}else if(substr($validity,-1) == "h"){
$validity = "Masa aktif:".substr($validity,0,-1)."Jam";}
if(substr($timelimit,-1) == "d" & strlen($timelimit) >3){
$timelimit = "Durasi:".((substr($timelimit,0,-1)*7) + substr($timelimit, 2,1))."Hari";
}else if(substr($timelimit,-1) == "d"){
$timelimit = "Durasi:".substr($timelimit,0,-1)."Hari";
}else if(substr($timelimit,-1) == "h"){
$timelimit = "Durasi:".substr($timelimit,0,-1)."Jam";
}else if(substr($timelimit,-1) == "w"){
$timelimit = "Durasi:".(substr($timelimit,0,-1)*7)."Hari";}
if($getprice == "1000"){ $color = "#FF1493";} 
elseif($getprice == "1000"){ $color = "#FF1493";}
elseif($getprice == "1500"){ $color = "#8E35EF";}
elseif($getprice == "2500"){ $color = "#FDBD01";}
elseif($getprice == "4000"){ $color = "#00FA9A";}
elseif($getprice == "10000"){ $color = "#E65100";}
else{ $color = "#E2F516";}?>
<style type="text/css">.rotate {
vertical-align: center;
text-align: center;
font-size: 20px;}.rotate span {
-ms-writing-mode: tb-rl;
-webkit-writing-mode: vertical-rl;
writing-mode: vertical-rl;
transform: rotate(180deg);
white-space: nowrap;}
<!--mks-mulai-->
</style>
<!--mks-border-mulai-->
<table class="voucher" style="border: 2px solid <?php echo $color;?>;width:308px;">
<!--mks-border-akhir-->	
<tbody>
<!--mks-price-->	
<tr>
<td style="font-weight: bold; border-right: 4px dotted white; color:#fff;background-color:<?php echo $color;?>; -webkit-print-color-adjust: exact;" class="rotate" rowspan="4"><span><?php echo $price;?></span></td>
<td style="font-weight: bold; border-left: 4px dotted white; color:#fff;background-color:<?php echo $color;?>; -webkit-print-color-adjust: exact;" class="rotate" rowspan="4"><span></span></td>	
<!--mks-price-akhir-->	
<!--mks-logo-->	
<td style="text-align: center;" colspan="3"><img src="<?php echo $logo;?>" alt="logo" style="height:25px;"> </td>
<!--mks-logo-akhir-->	

<!--mks-voucher-->	
<tr>
<?php if($usermode == "vc"){?> 
<td style="width: 100%; font-weight: bold; font-size: 25px; color:#111; text-align: center;"><?php echo $username;?></td>
<?php }elseif($usermode == "up"){?>
<td style="width: 100%; font-weight: bold; font-size: 17px; color:<?php echo $color;?>; text-align: center;"><?php echo "User: ".$username."<br>Pass: ".$password;?></td>
<?php }?> 
<!--mks-voucher-akhir-->
<!--mks-limitasi-mulai-->	
</tr>
<tr>
<td style="font-weight: bold; font-size: 12px; color:#000000;text-align: center;"><?php echo $validity;?> <?php echo $timelimit;?> <?php echo $datalimit;?></td>
</tr>
<!--mks-limitasi-akhir-->
<!--mks-cs-mulai-->	
<tr>
<td colspan="4" style="font-size: 10px;text-align: center;">
Gunakanlah Internet dengan bijak 
</tr>
</tbody>
</table> 
<!--mks-cs-akhir-->
<!--mks-selesai-->	        	        	        	        	        	        	        	        	        