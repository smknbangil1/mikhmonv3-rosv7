
Logo :
<img src="<?= $logo; ?>" style="height:30px;border:0;">

Hotspotname :
<?= $hotspotname; ?>

Username :
<?= $username; ?>

Password :
<?= $password; ?>

Validity :
<?= $validity; ?>

Time Limit :
<?= $timelimit; ?>

Data Limit :
<?= $datalimit; ?>

Price :
<?= $price; ?>

Profile :
<?= $profile; ?>

Comment :
<?= $comment; ?>

DNS Name Hotspot :
<?= $dnsname; ?>

QR Code :
<?= $qrcode ?>

Number Voucher:
<?= $num; ?>
<span id="num"><?= " [$num]"; ?></span>

Conditional :
$usermode = "vc"
username = password

$usermode = "up"
username & password